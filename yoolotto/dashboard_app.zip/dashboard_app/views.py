from django.shortcuts import render,render_to_response,redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from yoolotto.rest.decorators import rest, Authenticate
from django.db.models import Sum,Count
from django.http import HttpResponse, HttpResponseNotFound,HttpResponseRedirect
from django.views.generic import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
import json
from datetime import datetime
import datetime
from yoolotto.dashboard_app.forms import EntriesForm,GoogleAnalyticsForm
from yoolotto.dashboard_app.models import Entries,GoogleAnalytics
import math
import csv
import glob

# Create your views here.
class FillDetails(View):
	@rest
	def get(self,request):
		form = EntriesForm()
		return render(request,'dashboard/entries.html',{'form': form})
		
	
	def post(self,request):
		form = EntriesForm(request.POST)
		if form.is_valid():
			entry = form.save(commit=False)
			#print "impressions",type(form.cleaned_data['impressions'])
			#print "revenue",type(form.cleaned_data['revenue'])
			impressions=float(form.cleaned_data['impressions'])
			revenue=float(form.cleaned_data['revenue'])
			#import pdb;
			#pdb.set_trace()
			try:
				entry.ecpm = round(float(revenue*1000)/impressions,2)
				print "ok"
				print entry.ecpm
			except:
				entry.ecpm=0
				print "error"
			entry.save()
			return HttpResponseRedirect("/dashboard/")


class DailyReport(View):
	def get(self,request):
		date=request.GET.get('date','')
		video_revenue_date_wise=Entries.objects.filter(provider_type='video',entry_date=date).aggregate(Sum('revenue'))['revenue__sum']
		banner_revenue_date_wise=Entries.objects.filter(provider_type='banner',entry_date=date).aggregate(Sum('revenue'))['revenue__sum']
		interstitial_revenue_date_wise=Entries.objects.filter(provider_type='interstitial',entry_date=date).aggregate(Sum('revenue'))['revenue__sum']
		sum_ecpm=Entries.objects.filter(provider_type__in=['video','banner','interstitial'],entry_date=date).aggregate(Sum('ecpm'))['ecpm__sum']
		count_ecpm=Entries.objects.filter(provider_type__in=['video','banner','interstitial'],entry_date=date).aggregate(Count('ecpm'))['ecpm__count']
		try:
			avg_ecpm=round(sum_ecpm/count_ecpm,2)
		except:
			avg_ecpm=0


		f = open('DailyReport-{0}.csv'.format(date),'wb')
		try:
		    writer = csv.writer(f)
		    writer.writerow( ('Date','Video revenue', 'Banner revenue', 'Interstitial revenue','Avg ecpm') )
		    writer.writerow( (date,video_revenue_date_wise, banner_revenue_date_wise, interstitial_revenue_date_wise, avg_ecpm) )
		finally:
		    f.close()
		return HttpResponse("Ok")
		
class MonthlyReport(View):
	def post(self,request):
		interesting_files = glob.glob("*.csv") 
		f = open('output.csv','wb')
		writer = csv.writer(f)
		writer.writerow(("Date","Video revenue","Banner revenue","Interstitial revenue"))
		for filename in interesting_files:
			f = open(filename, 'rb')
			header = next(f,"None")
			reader=csv.reader(f)
			for line in reader:
				writer.writerow(line)

		return HttpResponse("Ok")
		


class GoogleAnalyticsDetail(View):
	@rest
	def get(self,request):
		form = GoogleAnalyticsForm()
		return render(request,'dashboard/googleanalytics.html',{'form': form})

	def post(self,request):
		form = GoogleAnalyticsForm(request.POST)
		if form.is_valid():
			form.save()
			# nos_of_devices=form.cleaned_data['nos_of_devices']
			# print type(nos_of_devices),nos_of_devices
			# device_type=form.cleaned_data['device']
			# print "device_type",device_type
			# print "Done"
			return HttpResponseRedirect("/dashboard/googleform/")
